# Timora Calendar App - Complete API Endpoints

Based on the complete event data structure, here are all the possible API endpoints for the Timora calendar application with Google Calendar integration.

## **Authentication Endpoints**

```http
POST   /api/auth/register
POST   /api/auth/login
POST   /api/auth/logout
POST   /api/auth/refresh
GET    /api/auth/me
POST   /api/auth/forgot-password
POST   /api/auth/reset-password
```

## **Google Calendar Integration**

```http
POST   /api/auth/google/connect
GET    /api/auth/google/callback
DELETE /api/auth/google/disconnect
GET    /api/auth/google/status
POST   /api/auth/google/sync
```

## **Event Management**

```http
GET    /api/events                    # Get all user events
POST   /api/events                    # Create event (+ Google Calendar)
GET    /api/events/:id                # Get specific event
PUT    /api/events/:id                # Update event (+ Google Calendar)
DELETE /api/events/:id                # Delete event (+ Google Calendar)
PATCH  /api/events/:id/status         # Update event status
POST   /api/events/:id/complete       # Mark event as completed
POST   /api/events/:id/duplicate      # Duplicate an event
POST   /api/events/:id/rating         # Add rating to completed event
PUT    /api/events/:id/completion     # Update completion notes
```

## **Event Filtering & Search**

```http
GET    /api/events/search             # Search events by query
GET    /api/events/filter             # Filter events by criteria
GET    /api/events/by-date/:date      # Get events for specific date
GET    /api/events/by-range           # Get events in date range
GET    /api/events/by-type/:type      # Get events by type
GET    /api/events/by-calendar/:id    # Get events by calendar
GET    /api/events/upcoming           # Get upcoming events
GET    /api/events/overdue            # Get overdue events
GET    /api/events/by-tag/:tag        # Get events by tag
GET    /api/events/by-subject/:subject # Get events by subject
GET    /api/events/by-course/:course   # Get events by course
GET    /api/events/by-professor/:prof  # Get events by professor
GET    /api/events/by-priority/:priority # Get events by priority
GET    /api/events/by-difficulty/:difficulty # Get events by difficulty
GET    /api/events/by-status/:status   # Get events by status
```

## **Recurring Events**

```http
POST   /api/events/:id/recurrence     # Create recurring series
PUT    /api/events/:id/recurrence     # Update recurring pattern
DELETE /api/events/:id/recurrence     # Remove recurrence
GET    /api/events/:id/instances      # Get all recurring instances
PUT    /api/events/:id/instances/:instanceId  # Update single instance
DELETE /api/events/:id/instances/:instanceId # Delete single instance
POST   /api/events/:id/instances/:instanceId/exception # Create exception
```

## **Checklist Management**

```http
GET    /api/events/:id/checklist      # Get event checklist
POST   /api/events/:id/checklist      # Add checklist item
PUT    /api/events/:id/checklist/:itemId    # Update checklist item
DELETE /api/events/:id/checklist/:itemId    # Delete checklist item
PATCH  /api/events/:id/checklist/:itemId/toggle  # Toggle item status
POST   /api/events/:id/checklist/reorder    # Reorder checklist items
GET    /api/events/:id/checklist/progress   # Get checklist progress
```

## **Study Partners & Collaboration**

```http
GET    /api/events/:id/partners       # Get study partners
POST   /api/events/:id/partners       # Add study partner
PUT    /api/events/:id/partners/:partnerId   # Update partner role
DELETE /api/events/:id/partners/:partnerId   # Remove study partner
POST   /api/events/:id/partners/:partnerId/invite    # Send invitation
PATCH  /api/events/:id/partners/:partnerId/status    # Accept/decline invitation
GET    /api/partners/invitations      # Get pending partner invitations
POST   /api/partners/invitations/:id/accept   # Accept invitation
POST   /api/partners/invitations/:id/decline  # Decline invitation
GET    /api/partners/search           # Search for study partners
```

## **Reminders**

```http
GET    /api/events/:id/reminders      # Get event reminders
POST   /api/events/:id/reminders      # Add reminder
PUT    /api/events/:id/reminders/:reminderId    # Update reminder
DELETE /api/events/:id/reminders/:reminderId    # Delete reminder
PATCH  /api/events/:id/reminders/:reminderId/toggle  # Toggle reminder active status
POST   /api/reminders/test/:reminderId # Test reminder delivery
```

## **File Attachments**

```http
GET    /api/events/:id/attachments    # Get event attachments
POST   /api/events/:id/attachments    # Upload attachment
DELETE /api/events/:id/attachments/:attachmentId  # Delete attachment
GET    /api/attachments/:id/download  # Download attachment
PUT    /api/attachments/:id           # Update attachment metadata
GET    /api/attachments/:id/preview   # Preview attachment
```

## **Calendar Management**

```http
GET    /api/calendars                 # Get user calendars
POST   /api/calendars                 # Create new calendar
GET    /api/calendars/:id             # Get specific calendar
PUT    /api/calendars/:id             # Update calendar
DELETE /api/calendars/:id             # Delete calendar
POST   /api/calendars/:id/share       # Share calendar
DELETE /api/calendars/:id/share/:userId  # Unshare calendar
GET    /api/calendars/shared          # Get calendars shared with user
PATCH  /api/calendars/:id/visibility  # Update calendar visibility
```

## **Tags & Categories**

```http
GET    /api/tags                      # Get all user tags
POST   /api/tags                      # Create new tag
PUT    /api/tags/:id                  # Update tag
DELETE /api/tags/:id                  # Delete tag
GET    /api/events/by-tag/:tag        # Get events by tag
GET    /api/tags/popular              # Get most used tags
POST   /api/tags/merge                # Merge multiple tags
```

## **Academic Data Management**

```http
GET    /api/subjects                  # Get all subjects
POST   /api/subjects                  # Create new subject
PUT    /api/subjects/:id              # Update subject
DELETE /api/subjects/:id              # Delete subject

GET    /api/courses                   # Get all courses
POST   /api/courses                   # Create new course
PUT    /api/courses/:id               # Update course
DELETE /api/courses/:id               # Delete course

GET    /api/professors                # Get all professors
POST   /api/professors                # Add new professor
PUT    /api/professors/:id            # Update professor
DELETE /api/professors/:id            # Delete professor

GET    /api/locations                 # Get all locations
POST   /api/locations                 # Add new location
PUT    /api/locations/:id             # Update location
DELETE /api/locations/:id             # Delete location
```

## **Analytics & Reports**

```http
GET    /api/analytics/overview        # Get user analytics overview
GET    /api/analytics/productivity    # Get productivity metrics
GET    /api/analytics/time-tracking   # Get time tracking data
GET    /api/analytics/completion-rate # Get task completion rates
GET    /api/analytics/study-patterns  # Get study pattern analysis
GET    /api/analytics/subject-performance # Get performance by subject
GET    /api/analytics/difficulty-trends    # Get difficulty trend analysis
GET    /api/analytics/weekly-summary  # Get weekly summary
GET    /api/analytics/monthly-report  # Get monthly report
GET    /api/analytics/semester-stats  # Get semester statistics
```

## **Notifications**

```http
GET    /api/notifications             # Get user notifications
PATCH  /api/notifications/:id/read    # Mark notification as read
DELETE /api/notifications/:id         # Delete notification
POST   /api/notifications/mark-all-read  # Mark all as read
GET    /api/notifications/settings    # Get notification preferences
PUT    /api/notifications/settings    # Update notification preferences
GET    /api/notifications/unread      # Get unread notifications count
POST   /api/notifications/test        # Test notification delivery
```

## **User Profile & Settings**

```http
GET    /api/user/profile              # Get user profile
PUT    /api/user/profile              # Update user profile
GET    /api/user/settings             # Get user settings
PUT    /api/user/settings             # Update user settings
GET    /api/user/preferences          # Get user preferences
PUT    /api/user/preferences          # Update preferences
DELETE /api/user/account              # Delete user account
POST   /api/user/change-password      # Change password
GET    /api/user/activity             # Get user activity log
```

## **Import/Export**

```http
POST   /api/import/icalendar          # Import from iCalendar
POST   /api/import/csv                # Import from CSV
POST   /api/import/json               # Import from JSON backup
GET    /api/export/icalendar          # Export to iCalendar
GET    /api/export/csv                # Export to CSV
GET    /api/export/json               # Export to JSON
GET    /api/export/pdf                # Export schedule as PDF
POST   /api/import/google-calendar    # Import from Google Calendar
```

## **External Integrations**

```http
POST   /api/integrations/zoom/connect          # Connect Zoom
POST   /api/integrations/zoom/create-meeting   # Create Zoom meeting for event
DELETE /api/integrations/zoom/disconnect       # Disconnect Zoom
GET    /api/integrations/status               # Get all integration statuses

POST   /api/integrations/outlook/connect      # Connect Outlook
DELETE /api/integrations/outlook/disconnect   # Disconnect Outlook
POST   /api/integrations/outlook/sync         # Sync with Outlook

POST   /api/integrations/slack/connect        # Connect Slack
DELETE /api/integrations/slack/disconnect     # Disconnect Slack
POST   /api/integrations/slack/notify         # Send Slack notification
```

## **Bulk Operations**

```http
POST   /api/events/bulk-create        # Create multiple events
PUT    /api/events/bulk-update        # Update multiple events
DELETE /api/events/bulk-delete        # Delete multiple events
POST   /api/events/bulk-complete      # Mark multiple events complete
POST   /api/events/bulk-reschedule    # Reschedule multiple events
POST   /api/events/bulk-export        # Export multiple events
```

## **Sync & Backup**

```http
POST   /api/sync/google-calendar      # Manual Google Calendar sync
GET    /api/sync/status               # Get sync status
POST   /api/backup/create             # Create data backup
GET    /api/backup/list               # List available backups
POST   /api/backup/restore/:id        # Restore from backup
DELETE /api/backup/:id                # Delete backup
GET    /api/sync/conflicts            # Get sync conflicts
POST   /api/sync/resolve-conflict     # Resolve sync conflict
```

## **Time Tracking**

```http
POST   /api/events/:id/time/start     # Start time tracking for event
POST   /api/events/:id/time/stop      # Stop time tracking for event
POST   /api/events/:id/time/pause     # Pause time tracking
POST   /api/events/:id/time/resume    # Resume time tracking
GET    /api/events/:id/time/log       # Get time tracking log
PUT    /api/events/:id/time/adjust    # Adjust tracked time
```

## **Notes & Objectives**

```http
GET    /api/events/:id/notes          # Get event notes
PUT    /api/events/:id/notes          # Update event notes
GET    /api/events/:id/prerequisites  # Get event prerequisites
PUT    /api/events/:id/prerequisites  # Update prerequisites
GET    /api/events/:id/objectives     # Get event objectives
PUT    /api/events/:id/objectives     # Update objectives
POST   /api/events/:id/reflection     # Add post-event reflection
```

## **Search & Discovery**

```http
GET    /api/search/global             # Global search across all data
GET    /api/search/events             # Search events with advanced filters
GET    /api/search/suggestions        # Get search suggestions
GET    /api/discover/similar          # Discover similar events
GET    /api/discover/recommended      # Get recommended events
GET    /api/discover/trending         # Get trending study topics
```

## **Mobile & Offline Support**

```http
GET    /api/offline/sync              # Get data for offline sync
POST   /api/offline/changes           # Upload offline changes
GET    /api/mobile/quick-add          # Quick add event (mobile optimized)
POST   /api/mobile/voice-to-event     # Convert voice note to event
GET    /api/mobile/widgets            # Get data for mobile widgets
```

---

## **Response Formats**

All endpoints return JSON responses with the following structure:

```json
{
  "success": true,
  "data": {},
  "message": "Operation completed successfully",
  "timestamp": "2025-09-27T10:30:00Z"
}
```

Error responses:

```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable error message",
    "details": {}
  },
  "timestamp": "2025-09-27T10:30:00Z"
}
```

## **Authentication**

Most endpoints require authentication via JWT token in the Authorization header:

```http
Authorization: Bearer <jwt_token>
```

## **Rate Limiting**

API endpoints are rate limited:

- Standard endpoints: 100 requests per minute
- Bulk operations: 10 requests per minute
- File uploads: 5 requests per minute

## **Pagination**

List endpoints support pagination:

```http
GET /api/events?page=1&limit=20&sort=startDate&order=desc
```

Response includes pagination metadata:

```json
{
  "data": [],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8,
    "hasNext": true,
    "hasPrev": false
  }
}
```
